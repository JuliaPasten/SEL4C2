//
//  UserResponses.swift
//  sel
//
//  Created by Fernando García on 03/10/23.
//

import Foundation
struct UserResponses:Codable{
    var user:String = ""
    var responses = Answers()
}

